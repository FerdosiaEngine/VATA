

ATENȚIONARE!

Pentru o funcționare corectă a limbajului, fișierele "package.json",
"package-lock.json" și cele ce se află în folderele VATA_modules nu pot fi
modificate. Pentru a executa o filă de cod în acest limbaj, aceasta trebuie
să aibă extensia ".vata". Toate filele cu această extensie trebuie să se
afle obligatoriu în folderul VATA_dependencies. Pentru a afișa rezultatul
codului, este necesar ca fila să existe și să fie scrisă conform regulilor
gramaticale ale limbajului VATA.

Klaus Bluseng.
