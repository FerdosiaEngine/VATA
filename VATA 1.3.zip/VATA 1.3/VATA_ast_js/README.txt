

ATENȚIONARE!

În timpul utilizării comenzilor, mai multe file necesare interpretării 
limbajului și afișării rezultatelor vor fi create. Acestea sunt stocate 
automat în folderul VATA_ast_js, fapt pentru care eliminarea lui nu este 
permisă. Totuși, toate filele din acesta (inclusiv actuala) pot fi șterse. 

Ferdosia Engine.